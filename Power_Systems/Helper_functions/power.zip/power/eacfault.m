function eacfault(p,eg,el,x1,x2,x3)

delta = linspace(0,pi,200);

P1 = (eg*el/x1).*sin(delta);
P2 = (eg*el/x2).*sin(delta);
P3 = (eg*el/x3).*sin(delta);

figure;
plot(delta*180/pi,P1,'b','LineWidth',2);
hold on;
plot(delta*180/pi,P2,'r','LineWidth',2);
plot(delta*180/pi,P3,'g','LineWidth',2);
yline(p,'k--','Mechanical Power');

xlabel('Power Angle (degrees)');
ylabel('Electrical Power (p.u.)');
title('Equal Area Criterion');
legend('Pre-fault','During Fault','Post-fault','Mechanical Power');
grid on;