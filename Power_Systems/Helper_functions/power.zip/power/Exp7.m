num=1;
den=[1 7.08 10.56 0.8];
figure(1), rlocus(num,den)
