clc;
clear all;
cost = [561 7.92 0.001562
310 7.85 0.00194
78 7.97 0.00482];
mwlimits = [150 600
100 400
50 200];
Pdt = 850
dispatch
gencost
